
# Sales Forecasting using Prophet (Simple)

**Author:** Meghna Dagdu Surwase (GitHub: https://github.com/meghnasurwase)

## Project Overview
This is a lightweight, recruiter-friendly time-series forecasting project using **Facebook Prophet**.
The project demonstrates loading retail monthly sales data, training a Prophet model, forecasting the next 12 months,
visualizing the forecast, and saving the results. It's designed to run locally or on Google Colab.

## Files
- `sales_data.csv` : Monthly sales data (columns: `ds` date, `y` sales value)
- `main.py` : Main script that trains Prophet and produces `forecast.csv` and `forecast_plot.png`
- `forecast.csv` : (created after running) forecasted values
- `forecast_plot.png` : (created after running) visualization image
- `requirements.txt` : Python dependencies

## How to run (local / Colab)

1. Create a Python 3.8+ environment and install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the script:
   ```bash
   python main.py
   ```
3. Outputs:
   - `forecast.csv` with columns `ds`, `yhat`, `yhat_lower`, `yhat_upper`
   - `forecast_plot.png` showing forecast and historical data

## Notes for Interview / README talking points
- Model: Facebook Prophet — chosen for ease-of-use and strong handling of seasonality and trends.
- Steps demonstrated: data loading, exploratory analysis, model training, forecasting, visualization.
- Extension ideas: deploy model on Google Cloud (Vertex AI or Cloud Run), schedule automatic ingestion from BigQuery, add exogenous regressors (promotions, holidays).

## Google Cloud / Deployment (Quick mention)
To show "cloud-ready" skills in applications:
- Push the repo to GitHub and mention: "Cloud-ready — can be containerized and deployed to Google Cloud Run or Vertex AI."
- Optionally upload dataset to BigQuery and use Vertex AI for model training at scale.

## License
MIT
