
# main.py - Sales Forecasting (Facebook Prophet) - Simple version
# Usage: python main.py
# Creates forecast for next 12 months and saves results to 'forecast.csv' and 'forecast_plot.png'

import pandas as pd
import matplotlib.pyplot as plt
try:
    from prophet import Prophet
except Exception as e:
    raise ImportError("Prophet is required. Install with: pip install prophet") from e
import os

DATA_PATH = os.path.join(os.path.dirname(__file__), "sales_data.csv")

def load_data(path=DATA_PATH):
    df = pd.read_csv(path, parse_dates=['ds'])
    # Prophet expects columns ds (date) and y (value)
    return df

def train_and_forecast(df, periods=12):
    m = Prophet(yearly_seasonality=True, daily_seasonality=False)
    m.fit(df)
    future = m.make_future_dataframe(periods=periods, freq='M')
    forecast = m.predict(future)
    return m, forecast

def plot_forecast(m, forecast, out_png="forecast_plot.png"):
    fig = m.plot(forecast)
    fig.savefig(out_png, bbox_inches='tight', dpi=150)
    print(f"Saved plot to {out_png}")

def save_forecast(forecast, out_csv="forecast.csv"):
    # Save date, yhat, yhat_lower, yhat_upper
    forecast[['ds','yhat','yhat_lower','yhat_upper']].to_csv(out_csv, index=False)
    print(f"Saved forecast to {out_csv}")

def main():
    print("Loading data...")
    df = load_data()
    print(df.head())
    print("Training Prophet model and forecasting...")
    m, forecast = train_and_forecast(df, periods=12)
    save_forecast(forecast, out_csv="forecast.csv")
    plot_forecast(m, forecast, out_png="forecast_plot.png")
    print("Done.")

if __name__ == '__main__':
    main()
